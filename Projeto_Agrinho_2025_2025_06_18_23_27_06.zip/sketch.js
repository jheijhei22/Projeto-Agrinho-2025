// =============================================================================
// Jogo "A Feira da Conexão: Do Campo à Cidade"
// Tema: Ligação Campo-Cidade, Empreendedorismo Agrícola
// Autor: Gemini
// Data: Junho de 2025
// =============================================================================

// Variáveis de estado do jogo
let gameState; // Estados: 'INICIO', 'CAMPO', 'PROCESSAMENTO', 'FEIRA', 'FIM_DE_JOGO'
let currentDay = 1; // Dia atual do jogo
const MAX_DAYS = 5; // Número máximo de dias para jogar

// Definição dos objetivos/temas para cada dia
const dayObjectives = [
  "", // Dia 0 (não usado, array é 0-indexed)
  "Dia 1: A Primeira Colheita! 🌱", // Dia 1
  "Dia 2: Transformando com a Vovó Sônia! 🍳", // Dia 2
  "Dia 3: Expandindo Horizontes na Feira! 💰", // Dia 3
  "Dia 4: Desafios e Oportunidades! 📈", // Dia 4
  "Dia 5: O Grande Dia da Conexão! 🤝" // Dia 5
];


// =============================================================================
// Variáveis do Jogador
// =============================================================================
let player = {
  money: 100, // Dinheiro inicial
  conhecimentoRural: 0, // Pontos de Conhecimento Rural
  empreendedorismo: 0, // Pontos de Empreendedorismo
  conexaoSocial: 0, // Pontos de Conexão Social
  inventory: { // Inventário de produtos
    // Produtos brutos do campo
    milho: 0,
    trigo: 0,
    tomate: 0,
    leite: 0,
    // Produtos processados
    fuba: 0,
    pao: 0,
    molhoTomate: 0,
    queijo: 0
  }
};

// =============================================================================
// Definição de Produtos
// =============================================================================
// Estrutura de produtos brutos
const RAW_PRODUCTS = [
  { name: 'milho', label: 'Milho', icon: '🌽', baseValue: 5, knowledgeGain: 5 },
  { name: 'trigo', label: 'Trigo', icon: '🌾', baseValue: 6, knowledgeGain: 5 },
  { name: 'tomate', label: 'Tomate', icon: '🍅', baseValue: 7, knowledgeGain: 5 },
  { name: 'leite', label: 'Leite', icon: '🥛', baseValue: 8, knowledgeGain: 5 }
];

// Estrutura de produtos processados (receitas)
const PROCESSED_PRODUCTS = [
  { name: 'fuba', label: 'Fubá', icon: '🍚', ingredients: { milho: 2 }, baseSellValue: 15, entrepreneurshipGain: 10 },
  { name: 'pao', label: 'Pão', icon: '🍞', ingredients: { trigo: 2 }, baseSellValue: 18, entrepreneurshipGain: 12 },
  { name: 'molhoTomate', label: 'Molho de Tomate', icon: '🥫', ingredients: { tomate: 2 }, baseSellValue: 20, entrepreneurshipGain: 13 },
  { name: 'queijo', label: 'Queijo', icon: '🧀', ingredients: { leite: 2 }, baseSellValue: 25, entrepreneurshipGain: 15 }
];

// =============================================================================
// Gerenciamento de Recursos no Campo
// =============================================================================
let fieldResources = []; // Recursos visíveis no campo para colheita
const MAX_FIELD_RESOURCES = 8; // Máximo de recursos na tela
const RESOURCE_SPAWN_INTERVAL = 120; // Intervalo para spawnar novos recursos (frames)
let lastSpawnTime = 0;

// =============================================================================
// Gerenciamento de Clientes na Feira
// =============================================================================
let customers = []; // Clientes na feira
const MAX_CUSTOMERS_PER_DAY = 5; // Quantidade de clientes que aparecerão por dia
const CUSTOMER_SPAWN_INTERVAL = 240; // Intervalo para spawnar clientes (frames)
let lastCustomerSpawnTime = 0;
let customersServedToday = 0;

// Variável para armazenar o produto selecionado na feira
let selectedProductForSale = null;

// =============================================================================
// Posições dos elementos da UI e Personagens
// =============================================================================
const playerSize = 80; // Tamanho do ícone do jogador
const npcSize = 70; // Tamanho dos ícones dos NPCs
const resourceSize = 40; // Tamanho dos ícones de recursos

// Posições gerais
const hudArea = { x: 0, y: 0, w: 800, h: 100 }; // Área para HUD (placar, dinheiro)

// Botões de navegação entre fases
let startButton;
let nextPhaseButton;
let finishDayButton;

// =============================================================================
// Funções p5.js Essenciais
// =============================================================================

function setup() {
  createCanvas(800, 600); // Cria a tela do jogo
  textSize(16); // Tamanho de fonte padrão
  textAlign(LEFT, TOP); // Alinhamento de texto padrão
  rectMode(CORNER); // Desenhar retângulos a partir do canto superior esquerdo

  // Define o estado inicial do jogo como tela de início
  gameState = 'INICIO';
  startButton = new Button('COMEÇAR JOGO', width / 2 - 80, height / 2 + 100, 160, 50, color(0, 150, 0));
}

function draw() {
  background(220); // Cor de fundo padrão

  // Lógica e desenho baseados no estado atual do jogo
  switch (gameState) {
    case 'INICIO':
      drawStartScreen();
      break;
    case 'CAMPO':
      drawHUD(); // Desenha HUD em todas as fases de jogo
      drawCampo();
      logicCampo();
      break;
    case 'PROCESSAMENTO':
      drawHUD();
      drawProcessamento();
      logicProcessamento();
      break;
    case 'FEIRA':
      drawHUD();
      drawFeira();
      logicFeira();
      break;
    case 'FIM_DE_JOGO':
      drawHUD(); // Exibir HUD final
      drawFimDeJogo();
      break;
  }
}

function mousePressed() {
  // Lógica de clique do mouse baseada no estado atual
  switch (gameState) {
    case 'INICIO':
      handleMousePressedStartScreen();
      break;
    case 'CAMPO':
      handleMousePressedCampo();
      break;
    case 'PROCESSAMENTO':
      handleMousePressedProcessamento();
      break;
    case 'FEIRA':
      handleMousePressedFeira();
      break;
  }

  // Lógica para botões de navegação (fora do switch de fases para ser mais genérico)
  if (nextPhaseButton && nextPhaseButton.isClicked(mouseX, mouseY)) {
    if (gameState === 'CAMPO') {
      gameState = 'PROCESSAMENTO';
    } else if (gameState === 'PROCESSAMENTO') {
      gameState = 'FEIRA';
      initFeiraDay(); // Prepara a feira para o dia atual
    }
    selectedProductForSale = null; // Reseta seleção ao mudar de fase
  }

  if (finishDayButton && finishDayButton.isClicked(mouseX, mouseY)) {
    if (gameState === 'FEIRA') {
      currentDay++;
      if (currentDay > MAX_DAYS) {
        gameState = 'FIM_DE_JOGO';
      } else {
        gameState = 'CAMPO'; // Volta para o campo para o próximo dia
        initDay(); // Reinicia as configurações do dia
      }
    }
    selectedProductForSale = null; // Reseta seleção ao mudar de fase
  }
}

// =============================================================================
// Fase: TELA DE INÍCIO
// =============================================================================

function drawStartScreen() {
  fill(50, 150, 200); // Azul claro para o fundo
  rect(0, 0, width, height);

  fill(255);
  textSize(40);
  textAlign(CENTER, CENTER);
  text('A Feira da Conexão', width / 2, height / 2 - 100);
  textSize(20);
  text('Do Campo à Cidade: Colhendo Oportunidades', width / 2, height / 2 - 50);

  textSize(16);
  textAlign(LEFT, TOP);
  let instructionsY = height / 2;
  text('Bem-vindo, jovem empreendedor!', 50, instructionsY);
  text('Sua missão é conectar o Campo e a Cidade.', 50, instructionsY + 25);
  text('1. Colha recursos no Campo (clique nos itens).', 50, instructionsY + 50);
  text('2. Processe-os em produtos valiosos na Estação.', 50, instructionsY + 75);
  text('3. Venda seus produtos na Feira da Cidade para clientes!', 50, instructionsY + 100);
  text('Ganhe pontos de Conhecimento Rural, Empreendedorismo e Conexão Social!', 50, instructionsY + 125);
  text('Clique em "COMEÇAR JOGO" para iniciar sua jornada!', 50, instructionsY + 150);


  // Botão "COMEÇAR JOGO"
  startButton.display();
}

function handleMousePressedStartScreen() {
  if (startButton.isClicked(mouseX, mouseY)) {
    gameState = 'CAMPO'; // Inicia o jogo
    initDay(); // Inicializa o primeiro dia de jogo
  }
}

// =============================================================================
// Funções de Inicialização de Dia / Fases
// =============================================================================

// Inicializa as variáveis para um novo dia (campo e processamento)
function initDay() {
  fieldResources = []; // Limpa recursos do campo
  // Popula o campo com alguns recursos iniciais
  for (let i = 0; i < MAX_FIELD_RESOURCES / 2; i++) {
    spawnFieldResource();
  }
  lastSpawnTime = frameCount; // Reinicia o contador de spawn

  // Reinicia variáveis da feira para garantir que clientes são novos
  customers = [];
  customersServedToday = 0;
  lastCustomerSpawnTime = 0;
  selectedProductForSale = null; // Garante que nenhum produto está selecionado

  // Cria/atualiza botões de navegação
  nextPhaseButton = new Button('Avançar para Processamento', width - 200, height - 40, 180, 30, color(100, 150, 255));
  finishDayButton = null; // Botão de finalizar dia só aparece na feira
}

// Inicializa variáveis específicas para a fase da feira (clientes)
function initFeiraDay() {
  customers = [];
  customersServedToday = 0;
  lastCustomerSpawnTime = frameCount;
  selectedProductForSale = null; // Garante que nenhum produto está selecionado

  // O botão de "Avançar" agora é "Finalizar Dia"
  finishDayButton = new Button('Finalizar Dia', width - 120, height - 40, 100, 30, color(200, 50, 50));
  nextPhaseButton = null; // Remove o botão de avançar de outras fases
}

// =============================================================================
// Funções de Desenho Comuns
// =============================================================================

// Desenha o HUD com informações do jogador
function drawHUD() {
  fill(50);
  rect(0, 0, width, hudArea.h); // Barra superior para o HUD

  fill(255);
  textSize(18);
  // Exibe o dia e o objetivo do dia
  text(`Dia: ${currentDay}/${MAX_DAYS} - ${dayObjectives[currentDay]}`, 20, 15);
  // Exibe a fase atual
  text(`Fase: ${getPhaseName()}`, 20, 40);

  text(`Dinheiro: R$ ${player.money.toFixed(2)}`, 200, 40); // Ajusta a posição
  text(`Conhecimento Rural: ${player.conhecimentoRural}`, 400, 15);
  text(`Empreendedorismo: ${player.empreendedorismo}`, 400, 40);
  text(`Conexão Social: ${player.conexaoSocial}`, 400, 65);

  // Exibir inventário
  textSize(14);
  text('Inventário:', 600, 10); // Move o inventário para a direita
  let yOffset = 0;
  for (let key in player.inventory) {
    if (player.inventory[key] > 0) {
      yOffset += 20;
      text(`${getProductLabel(key)}: ${player.inventory[key]}`, 600, 10 + yOffset);
    }
  }
}

// Função auxiliar para obter o nome da fase atual
function getPhaseName() {
  switch (gameState) {
    case 'CAMPO': return 'Campo (Colheita)';
    case 'PROCESSAMENTO': return 'Processamento (Criação)';
    case 'FEIRA': return 'Feira (Venda)';
    case 'FIM_DE_JOGO': return 'Fim do Jogo';
    default: return '';
  }
}

// Função auxiliar para obter o label de um produto pelo seu nome de chave
function getProductLabel(name) {
  let product = RAW_PRODUCTS.find(p => p.name === name);
  if (product) return product.label;
  product = PROCESSED_PRODUCTS.find(p => p.name === name);
  if (product) return product.label;
  return name; // Caso não encontre, retorna o nome da chave
}

// Função auxiliar para obter o ícone de um produto
function getProductIcon(name) {
  let product = RAW_PRODUCTS.find(p => p.name === name);
  if (product) return product.icon;
  product = PROCESSED_PRODUCTS.find(p => p.name === name);
  if (product) return product.icon;
  return '?'; // Ícone padrão
}

// =============================================================================
// Fase: CAMPO
// =============================================================================

// Desenha a cena do campo
function drawCampo() {
  fill(120, 200, 100); // Fundo verde para o campo
  rect(0, hudArea.h, width, height - hudArea.h);

  // Instrução para o jogador
  fill(0, 0, 0, 150); // Fundo para a instrução
  rect(width / 2 - 180, hudArea.h + 20, 360, 30, 5);
  fill(255);
  textSize(16);
  textAlign(CENTER, TOP);
  text('Clique nos recursos para colher!', width / 2, hudArea.h + 25);
  textAlign(LEFT, TOP); // Reset

  // Desenhar o player (simplificado)
  fill(50, 150, 50);
  ellipse(width / 2, height - 50, playerSize, playerSize);
  fill(255);
  textSize(16);
  textAlign(CENTER, CENTER);
  text('Você', width / 2, height - 50);
  textAlign(LEFT, TOP); // Reset

  // Desenhar Dona Sônia (NPC)
  fill(255, 180, 200); // Cor de pele
  ellipse(100, height - 100, npcSize, npcSize);
  fill(255);
  textSize(14);
  textAlign(CENTER, CENTER);
  text('Dona Sônia', 100, height - 100 + npcSize / 2 + 5);
  fill(0);
  textSize(12);
  text('Olá, jovem agricultor! Colete com sabedoria. 👩‍🌾', 100, height - 100 - npcSize / 2 - 15); // Balão de fala
  textAlign(LEFT, TOP); // Reset

  // Desenhar recursos do campo
  for (let resource of fieldResources) {
    fill(100, 100, 255); // Cor do botão
    rect(resource.x, resource.y, resource.w, resource.h, 5); // Retângulo para o recurso
    fill(255);
    textSize(24);
    textAlign(CENTER, CENTER);
    text(resource.icon, resource.x + resource.w / 2, resource.y + resource.h / 2);
    textSize(14);
    text(resource.label, resource.x + resource.w / 2, resource.y + resource.h + 15);
    textAlign(LEFT, TOP); // Reset
  }

  // Desenhar botão de avançar
  nextPhaseButton.display();
}

// Lógica da fase do campo
function logicCampo() {
  // Spawnar novos recursos periodicamente
  if (frameCount - lastSpawnTime > RESOURCE_SPAWN_INTERVAL && fieldResources.length < MAX_FIELD_RESOURCES) {
    spawnFieldResource();
    lastSpawnTime = frameCount;
  }
}

// Lida com cliques na fase do campo
function handleMousePressedCampo() {
  // Verificar se clicou em um recurso para colher
  for (let i = fieldResources.length - 1; i >= 0; i--) {
    let res = fieldResources[i];
    if (mouseX > res.x && mouseX < res.x + res.w && mouseY > res.y && mouseY < res.y + res.h) {
      // Colher o recurso
      player.inventory[res.name]++;
      player.conhecimentoRural += res.knowledgeGain;
      fieldResources.splice(i, 1); // Remove o recurso colhido
      console.log(`Colheu ${res.label}. Inventário: ${player.inventory[res.name]}`);
      break; // Sai do loop após colher um recurso
    }
  }
}

// Gera um novo recurso aleatório no campo
function spawnFieldResource() {
  const randProduct = random(RAW_PRODUCTS);
  const x = random(50, width - 50 - resourceSize);
  const y = random(hudArea.h + 50, height - 150 - resourceSize); // Evita sobrepor NPCs e HUD
  fieldResources.push({
    name: randProduct.name,
    label: randProduct.label,
    icon: randProduct.icon,
    x: x,
    y: y,
    w: resourceSize,
    h: resourceSize,
    knowledgeGain: randProduct.knowledgeGain
  });
}

// =============================================================================
// Fase: PROCESSAMENTO
// =============================================================================

// Desenha a cena de processamento
function drawProcessamento() {
  fill(180, 180, 180); // Fundo cinza claro para a área de processamento
  rect(0, hudArea.h, width, height - hudArea.h);

  fill(50);
  textSize(24);
  textAlign(CENTER, TOP);
  text('Estação de Processamento', width / 2, hudArea.h + 30);
  textAlign(LEFT, TOP); // Reset

  // Instrução para o jogador
  fill(0, 0, 0, 150); // Fundo para a instrução
  rect(width / 2 - 200, hudArea.h + 70, 400, 30, 5);
  fill(255);
  textSize(16);
  textAlign(CENTER, TOP);
  text('Clique em "Processar" para transformar seus recursos!', width / 2, hudArea.h + 75);
  textAlign(LEFT, TOP); // Reset

  // Desenhar as receitas disponíveis
  let xOffset = 50;
  let yOffset = hudArea.h + 120; // Ajustado para não colidir com a instrução
  textSize(16);

  for (let i = 0; i < PROCESSED_PRODUCTS.length; i++) {
    let recipe = PROCESSED_PRODUCTS[i];
    let canProcess = true;
    let ingredientsText = '';

    // Verificar se tem ingredientes
    for (let ing in recipe.ingredients) {
      ingredientsText += `${getProductLabel(ing)}: ${recipe.ingredients[ing]} / ${player.inventory[ing] || 0} `;
      if (player.inventory[ing] < recipe.ingredients[ing]) {
        canProcess = false;
      }
    }

    // Desenhar a caixa da receita
    fill(200);
    rect(xOffset, yOffset + i * 80, width - 100, 70, 5);
    fill(0);
    text(`${recipe.label} ${recipe.icon}`, xOffset + 10, yOffset + i * 80 + 10);
    textSize(12);
    text(`Ingredientes: ${ingredientsText}`, xOffset + 10, yOffset + i * 80 + 30);
    text(`Vende por: R$ ${recipe.baseSellValue}`, xOffset + 10, yOffset + i * 80 + 50);

    // Desenhar botão "Processar"
    if (canProcess) {
      fill(50, 200, 50); // Verde se pode processar
    } else {
      fill(150); // Cinza se não pode processar
    }
    rect(xOffset + width - 100 - 80, yOffset + i * 80 + 20, 70, 30, 5);
    fill(255);
    textSize(14);
    textAlign(CENTER, CENTER);
    text('Processar', xOffset + width - 100 - 80 + 35, yOffset + i * 80 + 20 + 15);
    textAlign(LEFT, TOP); // Reset
  }

  // Desenhar botão de avançar
  nextPhaseButton.display();
}

// Lógica da fase de processamento
function logicProcessamento() {
  // Nenhuma lógica contínua, apenas espera por interação do mouse
}

// Lida com cliques na fase de processamento
function handleMousePressedProcessamento() {
  let xOffset = 50;
  let yOffset = hudArea.h + 120; // Ajustado

  for (let i = 0; i < PROCESSED_PRODUCTS.length; i++) {
    let recipe = PROCESSED_PRODUCTS[i];
    let processButtonX = xOffset + width - 100 - 80;
    let processButtonY = yOffset + i * 80 + 20;
    let processButtonW = 70;
    let processButtonH = 30;

    // Se o botão de "Processar" foi clicado
    if (mouseX > processButtonX && mouseX < processButtonX + processButtonW &&
        mouseY > processButtonY && mouseY < processButtonY + processButtonH) {

      let canProcess = true;
      for (let ing in recipe.ingredients) {
        if (player.inventory[ing] < recipe.ingredients[ing]) {
          canProcess = false;
          break;
        }
      }

      if (canProcess) {
        // Consome ingredientes
        for (let ing in recipe.ingredients) {
          player.inventory[ing] -= recipe.ingredients[ing];
        }
        // Adiciona produto processado
        player.inventory[recipe.name]++;
        player.empreendedorismo += recipe.entrepreneurshipGain;
        console.log(`Processou ${recipe.label}. Inventário: ${player.inventory[recipe.name]}`);
      } else {
        console.log(`Não há ingredientes suficientes para ${recipe.label}.`);
      }
      break; // Sai do loop após tentar processar uma receita
    }
  }
}

// =============================================================================
// Fase: FEIRA
// =============================================================================

// Desenha a cena da feira
function drawFeira() {
  fill(150, 100, 80); // Fundo marrom para a feira
  rect(0, hudArea.h, width, height - hudArea.h);

  fill(50);
  textSize(24);
  textAlign(CENTER, TOP);
  text('Sua Banca na Feira', width / 2, hudArea.h + 30);
  textAlign(LEFT, TOP); // Reset

  // Instrução para o jogador
  fill(0, 0, 0, 150); // Fundo para a instrução
  rect(width / 2 - 200, hudArea.h + 70, 400, 30, 5);
  fill(255);
  textSize(16);
  textAlign(CENTER, TOP);
  text('1. Clique no produto. 2. Clique no cliente! 🤝', width / 2, hudArea.h + 75);
  textAlign(LEFT, TOP); // Reset

  // Desenhar produtos na banca
  let productX = 50;
  let productY = hudArea.h + 120; // Ajustado para não colidir com a instrução
  let productCount = 0;
  textSize(20);
  for (let prod of PROCESSED_PRODUCTS) {
    if (player.inventory[prod.name] > 0) {
      fill(255, 255, 150); // Cor de fundo do item
      stroke(selectedProductForSale === prod.name ? color(255, 0, 0) : 0); // Borda vermelha se selecionado
      strokeWeight(selectedProductForSale === prod.name ? 3 : 1); // Espessura da borda
      rect(productX + productCount * 80, productY, 70, 70, 5);
      noStroke(); // Remove a borda para o texto/ícone
      fill(0);
      textAlign(CENTER, CENTER);
      text(prod.icon, productX + productCount * 80 + 35, productY + 35);
      textSize(12);
      text(`${prod.label} (${player.inventory[prod.name]})`, productX + productCount * 80 + 35, productY + 70 + 10);
      textAlign(LEFT, TOP); // Reset
      productCount++;
    }
  }
  strokeWeight(1); // Resetar espessura da borda globalmente

  // Desenhar clientes
  for (let customer of customers) {
    customer.display();
  }

  // Desenhar Sr. Joaquim (NPC da Feira/Caminho - simplificado para a feira)
  fill(100, 100, 150); // Cor para o Sr. Joaquim
  ellipse(width - 100, height - 100, npcSize, npcSize);
  fill(255);
  textSize(14);
  textAlign(CENTER, CENTER);
  text('Sr. Joaquim', width - 100, height - 100 + npcSize / 2 + 5);
  fill(0);
  textSize(12);
  text('Precisa de um acordo rápido? 🤝', width - 100, height - 100 - npcSize / 2 - 15);
  textAlign(LEFT, TOP); // Reset

  // Desenhar botão de finalizar dia
  finishDayButton.display();
}

// Lógica da fase da feira
function logicFeira() {
  // Spawnar novos clientes periodicamente
  if (frameCount - lastCustomerSpawnTime > CUSTOMER_SPAWN_INTERVAL && customersServedToday < MAX_CUSTOMERS_PER_DAY) {
    spawnCustomer();
    lastCustomerSpawnTime = frameCount;
  }

  // Atualizar clientes (movimento, etc.)
  for (let i = customers.length - 1; i >= 0; i--) {
    customers[i].update();
    // Remover clientes que saíram da tela ou foram atendidos
    if (customers[i].isGone || customers[i].isServed) {
      customers.splice(i, 1);
    }
  }
}

// Lida com cliques na fase da feira
function handleMousePressedFeira() {
  // Lógica de venda (clicar no produto e depois no cliente)

  // 1. Verificar se algum produto na banca foi clicado
  let productX = 50;
  let productY = hudArea.h + 120; // Ajustado
  let productClicked = false;

  let tempSelectedProduct = null;
  let productCount = 0;
  for (let prod of PROCESSED_PRODUCTS) {
    if (player.inventory[prod.name] > 0) {
      if (mouseX > (productX + productCount * 80) && mouseX < (productX + productCount * 80 + 70) &&
          mouseY > productY && mouseY < productY + 70) {
        tempSelectedProduct = prod.name;
        productClicked = true;
        break;
      }
      productCount++;
    }
  }

  if (productClicked) {
    // Se clicou em um produto, ele se torna o produto selecionado
    if (selectedProductForSale === tempSelectedProduct) {
      // Se clicou no mesmo produto novamente, deseleciona
      selectedProductForSale = null;
    } else {
      // Seleciona o novo produto
      selectedProductForSale = tempSelectedProduct;
    }
    return; // Sai da função para evitar processar cliques de clientes no mesmo frame
  }

  // 2. Se um produto já está selecionado E um cliente foi clicado
  if (selectedProductForSale) {
    for (let customer of customers) {
      if (customer.isClicked(mouseX, mouseY)) {
        if (player.inventory[selectedProductForSale] > 0 && customer.desiredProduct === selectedProductForSale) {
          // Venda bem-sucedida!
          player.inventory[selectedProductForSale]--;
          player.money += PROCESSED_PRODUCTS.find(p => p.name === selectedProductForSale).baseSellValue;
          player.empreendedorismo += 15; // Ganho por venda
          player.conexaoSocial += 10; // Ganho por satisfazer cliente
          customer.isServed = true;
          customersServedToday++;
          console.log(`Vendeu ${selectedProductForSale} para um cliente!`);
        } else {
          console.log(`Cliente não quer ${selectedProductForSale} ou você não tem o produto.`);
          // Poderia adicionar uma penalidade leve ou apenas não fazer nada
        }
        selectedProductForSale = null; // Resetar seleção após tentativa de venda
        break; // Atendeu um cliente, sair
      }
    }
  }
}

// Gera um novo cliente aleatório para a feira
function spawnCustomer() {
  if (customers.length >= 3) return; // Limita clientes simultâneos na tela para não sobrecarregar

  const randProduct = random(PROCESSED_PRODUCTS);
  const x = width + 50; // Começa fora da tela, à direita
  const y = random(hudArea.h + 150, height - 150); // Posição vertical aleatória
  customers.push(new Customer(x, y, randProduct.name));
}


// =============================================================================
// Fase: FIM DE JOGO
// =============================================================================

// Desenha a tela de fim de jogo
function drawFimDeJogo() {
  fill(50, 50, 80); // Fundo escuro para a tela final
  rect(0, hudArea.h, width, height - hudArea.h);

  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text('Jornada Concluída!', width / 2, height / 2 - 100);

  textSize(24);
  text('Sua Colheita de Oportunidades:', width / 2, height / 2 - 40);
  textSize(20);
  text(`Dinheiro Final: R$ ${player.money.toFixed(2)}`, width / 2, height / 2);
  text(`Conhecimento Rural Total: ${player.conhecimentoRural}`, width / 2, height / 2 + 30);
  text(`Empreendedorismo Total: ${player.empreendedorismo}`, width / 2, height / 2 + 60);
  text(`Conexão Social Total: ${player.conexaoSocial}`, width / 2, height / 2 + 90);

  // Mensagem de sucesso/incentivo baseada nos pontos
  let finalMessage = "Você se tornou um grande elo entre o campo e a cidade!";
  if (player.money < 200) {
    finalMessage = "Sua jornada está começando! Continue aprendendo e crescendo.";
  } else if (player.money >= 200 && player.money < 400) {
    finalMessage = "Parabéns! Você construiu boas conexões e oportunidades.";
  } else {
    finalMessage = "Fantástico! Você é um mestre em colher oportunidades!";
  }
  textSize(18);
  text(finalMessage, width / 2, height - 50);

  textAlign(LEFT, TOP); // Reset
}

// =============================================================================
// Classes de Componentes do Jogo
// =============================================================================

// Classe genérica para um botão
class Button {
  constructor(label, x, y, w, h, color) {
    this.label = label;
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.color = color;
  }

  display() {
    fill(this.color);
    rect(this.x, this.y, this.w, this.h, 5); // Borda arredondada
    fill(255);
    textSize(14);
    textAlign(CENTER, CENTER);
    text(this.label, this.x + this.w / 2, this.y + this.h / 2);
    textAlign(LEFT, TOP); // Reset
  }

  isClicked(mx, my) {
    return mx > this.x && mx < this.x + this.w && my > this.y && my < this.y + this.h;
  }
}

// Classe para Clientes na Feira
class Customer {
  constructor(x, y, desiredProduct) {
    this.x = x;
    this.y = y;
    this.w = 60;
    this.h = 60;
    this.speed = random(0.5, 1.5); // Velocidade de movimento
    this.desiredProduct = desiredProduct; // Produto que o cliente deseja (nome da chave)
    this.isServed = false; // Se o cliente foi atendido
    this.isGone = false; // Se o cliente saiu da tela
    this.initialX = x; // Para calcular a distância percorrida
  }

  display() {
    if (this.isServed) return; // Não desenha se já foi atendido

    fill(255, 200, 180); // Cor de pele do cliente
    ellipse(this.x + this.w / 2, this.y + this.h / 2, this.w, this.h);
    fill(0);
    textSize(16);
    textAlign(CENTER, CENTER);
    text('🧑‍🤝‍🧑', this.x + this.w / 2, this.y + this.h / 2); // Ícone de pessoa (emoji)
    textAlign(LEFT, TOP); // Reset

    // Balão de fala com o produto desejado
    fill(255);
    rect(this.x + this.w / 2, this.y - 40, 80, 30, 5); // Balão
    fill(0);
    textSize(14);
    textAlign(CENTER, CENTER);
    text(getProductIcon(this.desiredProduct), this.x + this.w / 2 + 10, this.y - 25);
    text(getProductLabel(this.desiredProduct), this.x + this.w / 2 + 10, this.y - 10);
    textAlign(LEFT, TOP); // Reset
  }

  update() {
    if (this.isServed) return;

    this.x -= this.speed; // Move o cliente para a esquerda

    if (this.x < -this.w) { // Se o cliente saiu da tela
      this.isGone = true;
    }
  }

  isClicked(mx, my) {
    return mx > this.x && mx < this.x + this.w && my > this.y && my < this.y + this.h;
  }
}

